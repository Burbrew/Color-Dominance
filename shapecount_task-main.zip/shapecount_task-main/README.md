# Shape Count Task

- Inputs: images in `input/` with N randomly placed, possibly overlapping, identical shapes (square, circle, triangle, or star). Each instance is randomly colored.
- Output: `solution.json` with mapping from filename to integer count:
  - Example:
    ```json
    {
      "predictions": {
        "image_1.png": 27,
        "image_2.png": 13
      }
    }
    ```
- Ground truth: `ground_truth_counts.json`

To generate inputs and ground truth:

```bash
python benchmark/tasks/shapematch/generate_inputs.py --out benchmark/tasks/shapematch --n 10 --min_n 10 --max_n 60 --min_size 24 --max_size 64
``` 