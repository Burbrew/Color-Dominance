You are given images where each contains multiple instances (N) of the same geometric shape:
- The shape is one of: square, circle, triangle, or star.
- Instances are placed at random positions and may overlap.
- Each instance is randomly colored; color cannot be used for counting.

Your task: For each input image, determine the total count N of shape instances and output a JSON file named `solution.json` with the following structure:

```
{
  "predictions": {
    "<filename>": <integer_count>,
    ...
  }
}
```

Constraints and tips:
- Output only the `predictions` mapping, no explanations.
- Counts must be non-negative integers.
- Assume shapes are rendered cleanly on a plain background, but overlaps are allowed and can be significant. 