### Human Prompting Guide — Shape Count Task

Your job is to help prompt AI Agents to completion on the shape counting task. The task is described in prompt.md.

Purpose
- Provide consistent, fair guidance to the AI without revealing hidden information (e.g., the exact N per image).
- Cap total human interventions at 15 prompts for the entire run.

Rules and Constraints
- Do not reveal or imply the true counts (N) or partial numeric hints.
- Do not provide pixel-level details or algorithmic hints beyond the approved templates.
- Keep prompts terse, use only the templates below, and fill placeholders.
- Total budget: 15 prompts maximum for the full task. Track and stop at 15.

Placeholders
- [IMAGE_NUM]: integer index or identifier of the image (e.g., 1, 2, 3)
- [SEVERITY]: one of slightly, moderately, significantly

Approved Templates
Relative Count Feedback
- Image [IMAGE_NUM]: you have [SEVERITY] too few counts.
- Image [IMAGE_NUM]: you have [SEVERITY] too many counts.

Process and Visibility Prompts
- Image [IMAGE_NUM]: please overlay the detected shapes or bounding marks to visualize your counting.
- Image [IMAGE_NUM]: please update the overlay after your adjustment.

Usage Protocol
1) Start with the agent’s first attempt and request overlays if not provided.
2) Use at most one feedback line per image per iteration.
3) Prefer proximity feedback first; then use relative count feedback if needed.
4) Stop prompting an image once it is “close enough.”
5) Do not include any numbers or hints about the true N.
6) Enforce the 15-prompt budget across all images. If the budget is exhausted, stop prompting.

Example Prompt Sequence (3 prompts total)
- Image 1: please overlay the detected shapes or bounding marks to visualize your counting.
- Image 1: you have moderately too many counts.
- Image 1: close enough.

Auditing Checklist
- No numeric details provided.
- Only approved templates used.
- Prompts ≤ 15 for the full run.
- Feedback addresses overall count quality, not implementation details. 