import os
import json
import random
from typing import Tuple
import math
from PIL import Image, ImageDraw

SHAPES = ["square", "circle", "triangle", "star"]


def random_color(exclude=None):
	exclude = set(exclude or [])
	colors = [(220, 20, 60), (65, 105, 225), (60, 179, 113), (255, 165, 0), (148, 0, 211), (0, 191, 255), (255, 99, 71), (154, 205, 50)]
	while True:
		color = random.choice(colors)
		if color not in exclude:
			return color


def draw_shape(draw: ImageDraw.ImageDraw, shape: str, center: Tuple[int, int], size: int, fill: Tuple[int, int, int]):
	cx, cy = center
	half = size // 2
	if shape == "square":
		draw.rectangle([cx - half, cy - half, cx + half, cy + half], fill=fill)
	elif shape == "circle":
		draw.ellipse([cx - half, cy - half, cx + half, cy + half], fill=fill)
	elif shape == "triangle":
		points = [
			(cx, cy - half),
			(cx - half, cy + half),
			(cx + half, cy + half)
		]
		draw.polygon(points, fill=fill)
	elif shape == "star":
		# 5-pointed star
		points = []
		for i in range(10):
			angle_deg = i * 36.0
			radius = half if i % 2 == 0 else int(half * 0.4)
			angle_rad = math.radians(angle_deg - 90.0)
			x = cx + int(radius * math.cos(angle_rad))
			y = cy + int(radius * math.sin(angle_rad))
			points.append((x, y))
		draw.polygon(points, fill=fill)
	else:
		raise ValueError(f"Unknown shape: {shape}")


def generate_dataset(output_dir: str, num_images: int = 10, image_size: int = 512, min_n: int = 10, max_n: int = 60, min_size: int = 24, max_size: int = 64):
	os.makedirs(output_dir, exist_ok=True)
	input_dir = os.path.join(output_dir, "input")
	os.makedirs(input_dir, exist_ok=True)
	gt = {}

	for i in range(1, num_images + 1):
		img = Image.new("RGB", (image_size, image_size), (255, 255, 255))
		draw = ImageDraw.Draw(img)

		shape_type = random.choice(SHAPES)
		N = random.randint(min_n, max_n)
		shape_size = random.randint(min_size, max_size)

		for _ in range(N):
			cx = random.randint(shape_size // 2, image_size - shape_size // 2)
			cy = random.randint(shape_size // 2, image_size - shape_size // 2)
			color = random_color()
			draw_shape(draw, shape_type, (cx, cy), shape_size, color)

		filename = f"image_{i}.png"
		img.save(os.path.join(input_dir, filename))
		gt[filename] = N

	# Write ground truth counts JSON next to task files
	with open(os.path.join(output_dir, "ground_truth_counts.json"), "w") as f:
		json.dump(gt, f, indent=2)

	# Optionally write targets.json for some agents
	targets_path = os.path.join(output_dir, "input", "targets.json")
	with open(targets_path, "w") as f:
		json.dump(gt, f, indent=2)


if __name__ == "__main__":
	import argparse
	parser = argparse.ArgumentParser()
	parser.add_argument("--out", default=os.path.dirname(__file__))
	parser.add_argument("--n", type=int, default=10, help="number of images")
	parser.add_argument("--min_n", type=int, default=10)
	parser.add_argument("--max_n", type=int, default=60)
	parser.add_argument("--min_size", type=int, default=24)
	parser.add_argument("--max_size", type=int, default=64)
	args = parser.parse_args()
	generate_dataset(args.out, args.n, min_n=args.min_n, max_n=args.max_n, min_size=args.min_size, max_size=args.max_size) 