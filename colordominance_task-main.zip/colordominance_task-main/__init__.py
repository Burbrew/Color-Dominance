# Color Dominance Detection Task
